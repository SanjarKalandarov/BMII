<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeedder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
//        Permission::create(['name'=>'08:30']);
//        Permission::create(['name'=>'10:30']);
//        Permission::create(['name'=>'11:30']);
//        Permission::create(['name'=>'13:30']);
//        Permission::create(['name'=>'15:00']);
//        Permission::create(['name'=>'16:20']);
    }
}
